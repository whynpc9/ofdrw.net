using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using Ofdrw.Net.Converter.Pdf.Geometry;
using Ofdrw.Net.Core.Models;
using Ofdrw.Net.Packaging;
using Ofdrw.Net.Reader.Keywords;
using Ofdrw.Net.Reader.Readers;

// Package-only public consumer. Invoke after the final CLI has actually produced
// AAA -> --- for the deterministic one-page original-OFL fixture.
if (args.Length != 6) throw new ArgumentException(
    "Expected: original-input.ofd changed-output.ofd original-font.ttf SHA256 BYTECOUNT ADVANCE_MM");
var inputPath = Path.GetFullPath(args[0]); var outputPath = Path.GetFullPath(args[1]);
var fontPath = Path.GetFullPath(args[2]); var expectedSha = args[3].ToLowerInvariant();
if (!int.TryParse(args[4], NumberStyles.None, CultureInfo.InvariantCulture, out var expectedLength) || expectedLength <= 0)
    throw new ArgumentException("Invalid original font length.");
if (!double.TryParse(args[5], NumberStyles.Float, CultureInfo.InvariantCulture, out var advance) ||
    !double.IsFinite(advance) || advance <= 0) throw new ArgumentException("Invalid sample advance.");
var font = await File.ReadAllBytesAsync(fontPath);
var hash = Convert.ToHexString(SHA256.HashData(font)).ToLowerInvariant();
Require(font.Length == expectedLength && hash == expectedSha, "Original full-font identity mismatch.");
var trusted = new OfdTrustedEmbeddedFontGeometryProvider(
    new[] { new OfdTrustedEmbeddedFontIdentity(hash, font.Length) });
await using var inputStream = File.OpenRead(inputPath);
var original = await new OfdReader().ReadAsync(inputStream);
await using var outputStream = File.OpenRead(outputPath);
var actual = await new OfdReader().ReadAsync(outputStream);
Require(original.Pages.Count == 1 && actual.Pages.Count == 1, "Sample page count changed.");
var sourceText = (OfdTextElement)original.Pages[0].Elements.Single();
var outputText = (OfdTextElement)actual.Pages[0].Elements.Single();
Require(sourceText.Text == "AAA" && outputText.Text == "---", "Sample text did not change exactly.");
Require(sourceText.ObjectId == "30" && outputText.ObjectId == "30", "Sample object anchor changed.");
Require(sourceText.FontResourceId == "10" && outputText.FontResourceId == "10", "Font resource ID changed.");
Require(actual.Fonts.Count == 1 && actual.Fonts[0].Data.Length == font.Length &&
    Convert.ToHexString(SHA256.HashData(actual.Fonts[0].Data)).ToLowerInvariant() == hash,
    "Output original-font bytes changed.");
var sourceA = new OfdKeywordLocator(trusted).Find(original, "A");
var outputDash = new OfdKeywordLocator(trusted).Find(actual, "-");
var outputAAA = new OfdKeywordLocator(trusted).Find(actual, "AAA");
Require(sourceA.IsComplete && outputDash.IsComplete && outputAAA.IsComplete,
    "Public locator returned incomplete evidence.");
Require(sourceA.Hits.Count == 3 && outputDash.Hits.Count == 3 && outputAAA.Hits.Count == 0,
    "Public locator hit count mismatch.");

// Public geometry oracle: construct a separate, single-hyphen package using the
// same full original font, page PhysicalBox, text root, size and first TextCode.
// The public Writer -> Reader -> Locator derives the real '-' metric. The
// transformed ink box is compared after translation to each expected replacement baseline.
var metricPackage = new OfdDocumentPackage();
metricPackage.Fonts.Add(new() { Id = "10", FontName = "OriginalOFL", FileName = "font.ttf", Data = font });
var metricPage = new OfdPage { Id = "1", XMillimeters = 5, YMillimeters = 7,
    WidthMillimeters = 200, HeightMillimeters = 200 };
var metricText = new OfdTextElement { ObjectId = "30", LayerId = "20", FontResourceId = "10",
    FontName = "OriginalOFL", Text = "-", XMillimeters = 20, YMillimeters = 30,
    WidthMillimeters = 100, HeightMillimeters = 50, FontSizeMillimeters = 4 };
metricText.Runs.Add(new() { Text = "-", XMillimeters = 2, YMillimeters = 8 });
metricPage.Elements.Add(metricText); metricPackage.Pages.Add(metricPage);
using var metricBytes = new MemoryStream();
await new OfdPackageWriter().WriteAsync(metricPackage, metricBytes);
metricBytes.Position = 0;
var metricReadback = await new OfdReader().ReadAsync(metricBytes);
var metricFound = new OfdKeywordLocator(trusted).Find(metricReadback, "-");
Require(metricFound.IsComplete && metricFound.Hits.Count == 1, "Public metric fixture failed.");
var metric = metricFound.Hits[0].Fragments.Single();
Require(metric.GlyphId != 0 && metric.InkQuadrilateralMillimeters is not null,
    "Real hyphen metric has no glyph/ink.");
Require(metric.FontSha256 == hash && metric.FontByteCount == font.Length,
    "Public metric font identity mismatch.");

var rows = new List<object>();
for (var i = 0; i < 3; i++)
{
    var anchor = sourceA.Hits[i].Fragments.Single();
    var glyph = outputDash.Hits[i].Fragments.Single();
    Require(anchor.FontSha256 == hash && glyph.FontSha256 == hash &&
        anchor.FontByteCount == font.Length && glyph.FontByteCount == font.Length,
        "Fragment font identity mismatch.");
    Require(anchor.FontResourceId == "10" && glyph.FontResourceId == "10", "Fragment resource mismatch.");
    Require(glyph.GlyphId == metric.GlyphId && glyph.GlyphId != 0, "Actual hyphen glyph ID mismatch.");
    Near(glyph.AdvanceXMillimeters, metric.AdvanceXMillimeters, "Hyphen X advance");
    Near(glyph.AdvanceYMillimeters, metric.AdvanceYMillimeters, "Hyphen Y advance");
    // The original A positions describe the input, not the three replacement
    // positions. A whole-range replacement preserves only its first anchor;
    // the remaining '-' scalars advance by the independently measured '-' glyph.
    Near(anchor.BaselineMillimeters.X, 17 + i * advance, "Original sample A X anchor");
    Near(anchor.BaselineMillimeters.Y, 31, "Original sample A Y anchor");
    var firstAnchor = sourceA.Hits[0].Fragments.Single().BaselineMillimeters;
    var expectedX = firstAnchor.X + i * metric.AdvanceXMillimeters;
    var expectedY = firstAnchor.Y + i * metric.AdvanceYMillimeters;
    Near(glyph.BaselineMillimeters.X, expectedX, "Replacement X anchor");
    Near(glyph.BaselineMillimeters.Y, expectedY, "Replacement Y anchor");
    var metricInk = metric.InkQuadrilateralMillimeters!;
    var actualInk = glyph.InkQuadrilateralMillimeters;
    Require(actualInk is not null && actualInk.Corners.Count == 4, "Actual ink corners missing.");
    var dx = expectedX - metric.BaselineMillimeters.X;
    var dy = expectedY - metric.BaselineMillimeters.Y;
    for (var corner = 0; corner < 4; corner++)
    {
        var point = actualInk.Corners[corner]; var expected = metricInk.Corners[corner];
        Require(double.IsFinite(point.X) && double.IsFinite(point.Y), "Nonfinite ink corner.");
        Near(point.X, expected.X + dx, $"Ink corner {corner} X");
        Near(point.Y, expected.Y + dy, $"Ink corner {corner} Y");
    }
    rows.Add(new { index = i, glyph.GlyphId, glyph.FontResourceId, glyph.FontSha256,
        glyph.FontByteCount, glyph.AdvanceXMillimeters, glyph.AdvanceYMillimeters,
        Baseline = new { glyph.BaselineMillimeters.X, glyph.BaselineMillimeters.Y },
        Corners = actualInk.Corners.Select(p => new { p.X, p.Y }).ToArray() });
}
Console.WriteLine(JsonSerializer.Serialize(new { outcome = "public-package-output-verified",
    originalInputSha256 = HashFile(inputPath), changedOutputSha256 = HashFile(outputPath),
    fontSha256 = hash, fontBytes = font.Length, metrics = rows,
    loadedOfdrwAssemblies = AppDomain.CurrentDomain.GetAssemblies()
        .Where(assembly => assembly.GetName().Name?.StartsWith("Ofdrw.Net.", StringComparison.Ordinal) == true)
        .Select(assembly => new { name = assembly.GetName().Name, path = assembly.Location,
            sha256 = HashFile(assembly.Location) }).OrderBy(assembly => assembly.name).ToArray() },
    new JsonSerializerOptions { WriteIndented = true }));
static void Require(bool value, string message) { if (!value) throw new InvalidDataException(message); }
static void Near(double actual, double expected, string name)
{
    if (!double.IsFinite(actual) || !double.IsFinite(expected) || Math.Abs(actual - expected) > 1e-9)
        throw new InvalidDataException($"{name}: actual={actual:R}, expected={expected:R}");
}
static string HashFile(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
