#!/usr/bin/env python3
"""Artifact-only failure jobs against exact prebuilt CLI/typed runner binaries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import threading
import time
import zipfile

SENTINEL = b'issue06-failure-target-sentinel\n'
MARKER = b'\nissue06-owned-external-input-marker-after-observed-partial-stage\n'


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.absolute()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def describe(path):
    if path.is_symlink():
        return {'kind': 'symlink', 'link': os.readlink(path), 'resolved_payload': identity(path) if path.is_file() else None}
    if path.is_file():
        return {'kind': 'file', **identity(path)}
    if path.is_dir():
        return {'kind': 'directory', 'members': [{'relative': str(x.relative_to(path)), **describe(x)} for x in sorted(path.rglob('*')) if x.is_file() or x.is_symlink()]}
    return {'kind': 'missing', 'path': str(path.absolute())}


class PartialStageWatcher:
    """Native vnode events; never a delay-based guess or an injected job callback."""
    def __init__(self, folder, input_path, full_length):
        self.folder, self.input, self.full_length = folder, input_path, full_length
        self.stop_event = threading.Event()
        self.record = {'supported': hasattr(select, 'kqueue'), 'triggered': False, 'events': [], 'error': None,
                       'observation': 'No partial stage observed yet; no late-phase claim.'}
        self.kq = None
        self.fds = {}
        self.thread = None
        if self.record['supported']:
            self.kq = select.kqueue()
            fd = os.open(folder, os.O_RDONLY); self.fds[fd] = None
            self.kq.control([select.kevent(fd, filter=select.KQ_FILTER_VNODE,
                flags=select.KQ_EV_ADD | select.KQ_EV_CLEAR,
                fflags=select.KQ_NOTE_WRITE)], 0, 0)
    def start(self):
        if self.kq is not None:
            self.thread = threading.Thread(target=self.watch, daemon=True); self.thread.start()
    def inspect(self, fd, path):
        size = os.fstat(fd).st_size
        self.record['events'].append({'event': 'stage-fstat', 'path': str(path), 'size': size, 'monotonic_ns': time.monotonic_ns()})
        if not self.record['triggered'] and 0 < size < self.full_length:
            self.record['triggered'] = True
            self.record['observed_partial_length'] = size
            self.record['full_noop_snapshot_length_bound'] = self.full_length
            self.record['observation'] = 'A real .ofdrw-save file had positive incomplete physical length before external mutation.'
            self.record['mutation_started_ns'] = time.monotonic_ns()
            # The input is exclusively this test's copy. Never modify source,
            # font, models, output stage, or any production owner/file handle.
            with self.input.open('ab') as actual:
                actual.write(MARKER); actual.flush(); os.fsync(actual.fileno())
            self.record['mutation_completed_ns'] = time.monotonic_ns()
            self.record['input_after_external_marker'] = identity(self.input)
            self.stop_event.set()
    def watch(self):
        try:
            deadline = time.monotonic() + 30
            while not self.stop_event.is_set() and time.monotonic() < deadline:
                # Timeout bounds the OS event wait. Filesystem enumeration occurs
                # only after a real directory vnode event, never timer polling.
                for event in self.kq.control([], 16, 0.1):
                    if self.stop_event.is_set():
                        break
                    path = self.fds.get(event.ident)
                    if path is None:
                        self.record['events'].append({'event': 'output-directory-vnode', 'flags': event.fflags, 'monotonic_ns': time.monotonic_ns()})
                        for candidate in sorted(self.folder.glob('.ofdrw-save-*.tmp')):
                            if candidate in self.fds.values():
                                continue
                            try:
                                fd = os.open(candidate, os.O_RDONLY)
                            except FileNotFoundError:
                                self.record['events'].append({'event': 'stage-vanished-before-open', 'path': str(candidate)}); continue
                            self.fds[fd] = candidate
                            self.kq.control([select.kevent(fd, filter=select.KQ_FILTER_VNODE,
                                flags=select.KQ_EV_ADD | select.KQ_EV_CLEAR,
                                fflags=select.KQ_NOTE_WRITE | select.KQ_NOTE_EXTEND | select.KQ_NOTE_DELETE | select.KQ_NOTE_RENAME)], 0, 0)
                            self.inspect(fd, candidate)
                            if self.stop_event.is_set(): break
                    else:
                        self.inspect(event.ident, path)
        except Exception as error:
            self.record['error'] = repr(error)
    def close(self):
        self.stop_event.set()
        if self.thread is not None: self.thread.join(1)
        if self.thread is not None and self.thread.is_alive():
            self.record['error'] = 'Native watcher did not stop within its bounded join.'
        for fd in self.fds:
            os.close(fd)
        if self.kq is not None: self.kq.close()


def check_snapshot(manifest):
    record = json.loads(manifest.read_text())
    snapshot = Path(record['snapshot'])
    for row in record['files']:
        path = snapshot / row['path']
        if identity(path)['sha256'] != row['sha256'] or path.stat().st_size != row['bytes']:
            raise SystemExit('Original binary snapshot drift: ' + row['path'])
    return record, snapshot / 'Ofdrw.Net.Cli.dll'


p = argparse.ArgumentParser()
p.add_argument('--snapshot-manifest', type=Path, required=True)
p.add_argument('--snapshot-manifest-sha256', required=True)
p.add_argument('--typed-dll-binding', type=Path, required=True)
p.add_argument('--typed-dll-binding-sha256', required=True)
p.add_argument('--input', type=Path, required=True)
p.add_argument('--font', type=Path, required=True)
p.add_argument('--destination', type=Path, required=True)
p.add_argument('--execute', action='store_true', help='Run only after the coordinator releases dotnet; otherwise save prepared plan only.')
a = p.parse_args()
if identity(a.snapshot_manifest)['sha256'] != a.snapshot_manifest_sha256 or identity(a.typed_dll_binding)['sha256'] != a.typed_dll_binding_sha256:
    raise SystemExit('Frozen binary manifest binding differs.')
baseline, cli = check_snapshot(a.snapshot_manifest)
typed = json.loads(a.typed_dll_binding.read_text())
runner = Path(typed['harness'])
# Inspect only the isolated typed runner runtime DLLs; do not depend on mutable
# primary/Low obj/bin or compare ZIP timestamps between independent jobs.
for row in typed['dlls']:
    path = Path(row['path'])
    if path.parent == runner.parent and (identity(path)['sha256'] != row['sha256'] or path.stat().st_size != row['bytes']):
        raise SystemExit('Typed runner binary drift: ' + str(path))
source_binding = Path(typed['diagnostic_source_binding'])
if identity(source_binding)['sha256'] != typed['diagnostic_source_binding_sha256']:
    raise SystemExit('Typed source binding drift.')
source_id, font_id = identity(a.input), identity(a.font)
if font_id['bytes'] != 21_659_544 or font_id['sha256'] != '3012a9b63f5eca3e3b38f23a1be5ed504675e394abf8e7a4fa981506582c04aa':
    raise SystemExit('This matrix requires the complete pinned original CJK font, no reduced F.')
with zipfile.ZipFile(a.input) as z:
    embedded = [{'entry': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name in z.namelist() if name.lower().endswith(('.ttf', '.otf')) for data in [z.read(name)]]
if not any(x['sha256'] == font_id['sha256'] and x['bytes'] == font_id['bytes'] for x in embedded):
    raise SystemExit('Original input does not embed the full pinned font.')
cases = ['same-path', 'output-symlink-input', 'wrong-trusted-sha', 'replacement-overflow', 'directory-target']
plan = {'status': 'artifact-only prepared failure jobs; not executed or acceptance',
        'head06': baseline['head06'], 'head09': baseline['head09'],
        'snapshot_manifest': identity(a.snapshot_manifest), 'typed_dll_binding': identity(a.typed_dll_binding),
        'source_binding': identity(source_binding), 'original_input': source_id, 'original_font': font_id, 'embedded_fonts': embedded,
        'unmodified_cli': identity(cli), 'typed_runner': identity(runner), 'script': identity(Path(__file__)),
        'four_default_caps': [536870912] * 4,
        'jobs': [{'case': case, 'binary': mode} for case in cases for mode in ['unmodified', 'typed']] + [{'case': 'late-input-marker', 'binary': 'typed'}],
        'late_observer': 'one bounded native kqueue attempt; append only after fstat 0<size<exact noop input length; absent/late/raced event => inconclusive',
        'new_context_semantics': 'Each independent process/job uses the original fresh ticket; no context reset/refund inside a job.', 'runs': []}
dest = a.destination.absolute()
if dest.exists(): raise SystemExit('Use a new evidence directory; no prior attempt is overwritten.')
dest.mkdir(parents=True)
(dest / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
if not a.execute:
    print(json.dumps({'status': 'prepared-only', 'plan': str(dest / 'plan.json'), 'sha256': identity(dest / 'plan.json')['sha256']})); raise SystemExit(0)
plan['status'] = 'actual failure observations pending; no whole-save acceptance'
for job in plan['jobs']:
    case, mode = job['case'], job['binary']
    folder = dest / (case + '-' + mode); folder.mkdir()
    temp = folder / 'tmp'; temp.mkdir()
    input_path, output, stats = folder / 'input.ofd', folder / 'output.ofd', folder / 'numeric-report.json'
    input_path.write_bytes(a.input.read_bytes()); output.write_bytes(SENTINEL)
    find, replacement, trust = 'AAA', '---', font_id['sha256']
    expected_target = describe(output)
    if case == 'same-path':
        output.unlink(); output = input_path; expected_target = describe(input_path)
    elif case == 'output-symlink-input':
        output.unlink(); output.symlink_to(input_path); expected_target = describe(output)
    elif case == 'wrong-trusted-sha': trust = '0' * 64
    elif case == 'replacement-overflow': replacement = 'A' * 64
    elif case == 'directory-target':
        output.unlink(); output.mkdir(); (output / 'sentinel.txt').write_bytes(SENTINEL); expected_target = describe(output)
    elif case == 'late-input-marker': replacement = 'AAA'
    replacements = [str(input_path), str(output), '--find', find, '--replace', replacement, '--trusted-font', f'{trust}:{font_id["bytes"]}']
    argv = ['dotnet', 'exec', str(runner), str(stats), '--', *replacements] if mode == 'typed' else ['dotnet', 'exec', str(cli), 'replace-text', *replacements]
    env = {'DOTNET_CLI_HOME': str(dest / 'cli-home'), 'DOTNET_SKIP_FIRST_TIME_EXPERIENCE': '1', 'DOTNET_CLI_TELEMETRY_OPTOUT': '1', 'TMPDIR': str(temp) + '/'}
    (dest / 'cli-home').mkdir(exist_ok=True)
    watch = None; timed_out = False
    before = identity(input_path); started = time.time()
    with (folder / 'stdout.log').open('w') as stdout, (folder / 'stderr.log').open('w') as stderr:
        if case == 'late-input-marker':
            watch = PartialStageWatcher(folder, input_path, before['bytes']); watch.start()
        process = subprocess.Popen(argv, cwd=folder, env={**os.environ, **env}, stdout=stdout, stderr=stderr)
        try: code = process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            timed_out = True; process.terminate()
            try: code = process.wait(timeout=5)
            except subprocess.TimeoutExpired: process.kill(); code = process.wait()
        finally:
            if watch is not None: watch.close()
    after = identity(input_path); target_after = describe(output)
    numeric = json.loads(stats.read_text()) if stats.exists() else None
    residuals = [describe(x) for x in sorted(temp.rglob('*')) if x.is_file() or x.is_symlink()]
    residuals += [describe(x) for x in sorted(folder.rglob('.ofdrw-*.tmp')) if x.is_file() or x.is_symlink()]
    input_same, target_same = before['sha256'] == after['sha256'], expected_target == target_after
    if case == 'late-input-marker':
        marker_exact = input_path.read_bytes() == a.input.read_bytes() + MARKER
        triggered = watch.record['triggered']
        status = ('observed-late-input-refusal' if triggered and marker_exact and code != 0 and target_same and not residuals and not timed_out
                  else 'inconclusive-late-window-or-unexpected-outcome')
    else:
        marker_exact = None
        status = 'observed-failure-preserved-state' if code != 0 and input_same and target_same and not residuals and not timed_out else 'unexpected-failure-matrix-outcome'
    row = {'case': case, 'binary': mode, 'status': status, 'argv': argv, 'env_overrides': env,
           'pid': process.pid, 'started': started, 'ended': time.time(), 'exit_code': code, 'timed_out': timed_out,
           'input_before': before, 'input_after': after, 'input_preserved': input_same,
           'target_before': expected_target, 'target_after': target_after, 'target_preserved': target_same,
           'remaining_owned_temps': residuals, 'external_marker_exact': marker_exact,
           'watch': watch.record if watch else None, 'font': font_id,
           'typed_report': identity(stats) if stats.exists() else None, 'numeric_report': numeric,
           'stdout': identity(folder / 'stdout.log'), 'stderr': identity(folder / 'stderr.log'),
           'stderr_text': (folder / 'stderr.log').read_text()}
    plan['runs'].append(row); (dest / 'results.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps({'case': case, 'binary': mode, 'status': status, 'exit_code': code, 'error': numeric.get('Error') if numeric else row['stderr_text']}), flush=True)
plan['status'] = 'actual failure matrix observations; late-window absence is inconclusive; no success/geometry/release acceptance'
plan['original_source_unchanged'] = identity(a.input) == source_id
plan['original_font_unchanged'] = identity(a.font) == font_id
# Binaries remain independently pinned; never substitute typed ZIP output for the
# previously unmodified published bytes or treat failed-phase Removed=false as cleanup failure.
check_snapshot(a.snapshot_manifest)
for row in typed['dlls']:
    path = Path(row['path'])
    if path.parent == runner.parent and identity(path)['sha256'] != row['sha256']:
        raise SystemExit('Typed binary drift after runs.')
(dest / 'results.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(identity(dest / 'results.json')))
